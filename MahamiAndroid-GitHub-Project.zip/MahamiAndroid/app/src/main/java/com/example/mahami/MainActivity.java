package com.example.mahami;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private LinearLayout taskContainer;
    private EditText taskInput;
    private ArrayList<String> tasks = new ArrayList<>();
    private ArrayList<Boolean> completed = new ArrayList<>();
    private SharedPreferences prefs;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("mahami_data", MODE_PRIVATE);
        loadTasks();
        buildScreen();
        renderTasks();
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density);
    }

    private TextView makeText(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(16));
        root.setBackgroundColor(Color.rgb(245, 247, 251));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = makeText("مهامي اليومية", 27, Color.rgb(28, 55, 95));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));

        TextView subtitle = makeText("نظّم يومك وأنجز أهدافك", 15, Color.DKGRAY);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(38)));

        LinearLayout entry = new LinearLayout(this);
        entry.setOrientation(LinearLayout.HORIZONTAL);
        entry.setGravity(Gravity.CENTER_VERTICAL);
        taskInput = new EditText(this);
        taskInput.setSingleLine(true);
        taskInput.setTextSize(16);
        taskInput.setHint("اكتب مهمة جديدة...");
        taskInput.setPadding(dp(12), 0, dp(12), 0);
        taskInput.setBackgroundColor(Color.WHITE);
        entry.addView(taskInput, new LinearLayout.LayoutParams(0, dp(52), 1));

        Button add = new Button(this);
        add.setText("إضافة");
        add.setTextSize(14);
        entry.addView(add, new LinearLayout.LayoutParams(dp(92), dp(52)));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(58));
        ep.topMargin = dp(14);
        root.addView(entry, ep);

        TextView heading = makeText("قائمة المهام", 20, Color.rgb(28, 55, 95));
        heading.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(55));
        hp.topMargin = dp(12);
        root.addView(heading, hp);

        ScrollView scroll = new ScrollView(this);
        taskContainer = new LinearLayout(this);
        taskContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(taskContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        add.setOnClickListener(v -> addTask());

        TextView footer = makeText("تطبيق تجريبي • الإصدار 1.0", 12, Color.GRAY);
        root.addView(footer, new LinearLayout.LayoutParams(-1, dp(35)));

        setContentView(root);
    }

    private void addTask() {
        String value = taskInput.getText().toString().trim();
        if (value.isEmpty()) {
            Toast.makeText(this, "اكتب المهمة أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        tasks.add(value);
        completed.add(false);
        taskInput.setText("");
        saveTasks();
        renderTasks();
    }

    private void renderTasks() {
        taskContainer.removeAllViews();
        if (tasks.isEmpty()) {
            TextView empty = makeText("لا توجد مهام بعد. أضف مهمتك الأولى!", 15, Color.GRAY);
            taskContainer.addView(empty, new LinearLayout.LayoutParams(-1, dp(100)));
            return;
        }

        for (int i = 0; i < tasks.size(); i++) {
            final int index = i;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(10), dp(6), dp(10), dp(6));
            card.setBackgroundColor(Color.WHITE);

            TextView task = new TextView(this);
            task.setText(tasks.get(i));
            task.setTextSize(16);
            task.setTextColor(completed.get(i) ? Color.GRAY : Color.rgb(35, 45, 60));
            task.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
            task.setPadding(dp(8), 0, dp(8), 0);
            if (completed.get(i)) task.setPaintFlags(task.getPaintFlags() | 0x10);
            card.addView(task, new LinearLayout.LayoutParams(0, dp(52), 1));

            Button done = new Button(this);
            done.setText(completed.get(i) ? "تم ✓" : "إنجاز");
            done.setTextSize(11);
            card.addView(done);

            Button delete = new Button(this);
            delete.setText("حذف");
            delete.setTextSize(11);
            card.addView(delete);

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(9);
            taskContainer.addView(card, cp);

            done.setOnClickListener(v -> {
                completed.set(index, !completed.get(index));
                saveTasks();
                renderTasks();
            });
            delete.setOnClickListener(v -> {
                tasks.remove(index);
                completed.remove(index);
                saveTasks();
                renderTasks();
            });
        }
    }

    private void saveTasks() {
        JSONArray array = new JSONArray();
        for (int i = 0; i < tasks.size(); i++) {
            JSONObject item = new JSONObject();
            try {
                item.put("task", tasks.get(i));
                item.put("done", completed.get(i));
                array.put(item);
            } catch (Exception ignored) {}
        }
        prefs.edit().putString("tasks", array.toString()).apply();
    }

    private void loadTasks() {
        String raw = prefs.getString("tasks", "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                tasks.add(item.getString("task"));
                completed.add(item.getBoolean("done"));
            }
        } catch (Exception ignored) {}
    }
}
